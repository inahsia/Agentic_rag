import { Hero } from "@/components/Hero";
import { Features } from "@/components/Features";
import { CTA } from "@/components/CTA";
import React, { useEffect, useState } from "react";
import { getDocs, askQuestion } from "../lib/api";
import "../App.css";

const Index = () => {
  const [docs, setDocs] = useState<string[]>([]);
  const [selectedDoc, setSelectedDoc] = useState<string>("");
  const [role, setRole] = useState<string>("General");
  const [question, setQuestion] = useState<string>("");
  const [answer, setAnswer] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");
  const [testMsg, setTestMsg] = useState<string>("");

  useEffect(() => {
    getDocs().then(setDocs).catch(() => setDocs([]));
  }, []);

  useEffect(() => {
    if (docs.length > 0) setSelectedDoc(docs[0]);
  }, [docs]);

  const handleAsk = async () => {
    setError("");
    setAnswer("");
    setLoading(true);
    try {
      const ans = await askQuestion({ question, role, doc_source: selectedDoc });
      setAnswer(ans);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const testBackend = async () => {
    try {
      const res = await fetch("http://localhost:5000/test");
      const data = await res.json();
      setTestMsg(data.message);
    } catch (e) {
      setTestMsg("Failed to connect to backend.");
    }
  };

  return (
    <div className="min-h-screen">
      <Hero />
      <Features />
      <div className="qa-box">
        <h2 className="qa-title">Ask a Question</h2>
        <div className="qa-row">
          <label className="qa-label">Document:</label>
          <select className="qa-select" value={selectedDoc} onChange={e => setSelectedDoc(e.target.value)}>
            {docs.map(doc => <option key={doc} value={doc}>{doc}</option>)}
          </select>
        </div>
        <div className="qa-row">
          <label className="qa-label">Role:</label>
          <select className="qa-select" value={role} onChange={e => setRole(e.target.value)}>
            <option>Engineer</option>
            <option>PM</option>
            <option>HR</option>
            <option>General</option>
          </select>
        </div>
        <div className="qa-row">
          <input
            className="qa-input"
            type="text"
            value={question}
            onChange={e => setQuestion(e.target.value)}
            placeholder="Ask your question about internal docs..."
          />
        </div>
        <button className="qa-btn" onClick={handleAsk} disabled={loading || !question || !selectedDoc}>
          {loading ? "Getting Answer..." : "Get Answer"}
        </button>
        {error && <div className="qa-error">{error}</div>}
        {answer && <div className="qa-answer"><b>Answer:</b><br />{answer}</div>}
      </div>
      <CTA />
    </div>
  );
};

export default Index;
