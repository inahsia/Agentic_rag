export async function getDocs(): Promise<string[]> {
  const res = await fetch("http://localhost:5000/docs");
  if (!res.ok) throw new Error("Failed to fetch docs");
  const data = await res.json();
  return data.docs;
}

export async function askQuestion({ question, role, doc_source }: { question: string; role: string; doc_source: string; }): Promise<string> {
  const res = await fetch("http://localhost:5000/ask", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ question, role, doc_source })
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || "Failed to get answer");
  }
  const data = await res.json();
  return data.answer;
} 