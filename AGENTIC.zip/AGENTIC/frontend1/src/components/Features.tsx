import { Card } from "@/components/ui/card";
import { 
  FileText, 
  MessageSquare, 
  Zap, 
  Shield, 
  Globe, 
  Brain,
  Slack,
  Search,
  Clock
} from "lucide-react";

const integrations = [
  {
    name: "Notion",
    icon: FileText,
    description: "Connect your team wikis and documentation",
    color: "text-slate-400"
  },
  {
    name: "Google Docs",
    icon: Globe,
    description: "Access shared documents and folders",
    color: "text-blue-400"
  },
  {
    name: "Confluence",
    icon: FileText,
    description: "Tap into corporate knowledge bases",
    color: "text-blue-600"
  },
  {
    name: "Slack",
    icon: Slack,
    description: "Get answers directly in your channels",
    color: "text-purple-400"
  }
];

const features = [
  {
    icon: Brain,
    title: "Smart Understanding",
    description: "AI that comprehends context, not just keywords. Ask naturally, get precise answers."
  },
  {
    icon: Zap,
    title: "Instant Responses",
    description: "Sub-second query processing. No more waiting or searching through endless folders."
  },
  {
    icon: Search,
    title: "Source Transparency",
    description: "Every answer comes with citations. See exactly where the information originated."
  },
  {
    icon: Shield,
    title: "Enterprise Security",
    description: "Your data stays yours. SOC 2 compliant with enterprise-grade encryption."
  },
  {
    icon: MessageSquare,
    title: "Multi-Channel Access",
    description: "Works in Slack, web chat, or API. Meet your team where they already work."
  },
  {
    icon: Clock,
    title: "Always Learning",
    description: "Continuously improves from team interactions and feedback loops."
  }
];

export const Features = () => {
  return (
    <div className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Integrations Section */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 animate-fade-in-up">
            Connects to Your <span className="text-primary">Entire Stack</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-12 animate-fade-in-delayed">
            One AI assistant that speaks to all your knowledge sources
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {integrations.map((integration, index) => (
              <Card 
                key={integration.name} 
                className="p-6 gradient-card border-accent/20 hover:glow-card transition-all duration-300 hover:scale-105 animate-scale-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="w-12 h-12 rounded-lg bg-muted/50 flex items-center justify-center">
                    <integration.icon className={`w-6 h-6 ${integration.color}`} />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">{integration.name}</h3>
                    <p className="text-sm text-muted-foreground">{integration.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Features Grid */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 animate-fade-in-up">
            Why Teams <span className="text-primary glow-text">Love</span> QueryIQ
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-12 animate-fade-in-delayed">
            Built for modern teams who value speed, accuracy, and beautiful experiences
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card 
              key={feature.title} 
              className="p-6 gradient-card border-accent/20 hover:glow-card transition-all duration-300 hover:scale-105 animate-fade-in-up"
              style={{ animationDelay: `${index * 0.1 + 0.2}s` }}
            >
              <div className="flex items-start space-y-4 flex-col">
                <div className="w-12 h-12 rounded-lg gradient-primary flex items-center justify-center flex-shrink-0">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};