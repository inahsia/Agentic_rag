import { Button } from "@/components/ui/button";
import { Sparkles, Brain, Zap } from "lucide-react";
import heroImage from "@/assets/ai-brain-hero.jpg";
import { useNavigate } from "react-router-dom";

export const Hero = () => {
  const navigate = useNavigate();
  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
        style={{
          backgroundImage: `url(${heroImage})`,
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-br from-background/90 via-background/70 to-primary/20" />
      
      {/* Floating Elements */}
      <div className="absolute top-20 left-10 animate-float">
        <Brain className="w-8 h-8 text-primary animate-pulse-glow" />
      </div>
      <div className="absolute top-32 right-20 animate-float" style={{ animationDelay: '-2s' }}>
        <Sparkles className="w-6 h-6 text-accent animate-pulse-glow" />
      </div>
      <div className="absolute bottom-32 left-20 animate-float" style={{ animationDelay: '-4s' }}>
        <Zap className="w-7 h-7 text-primary animate-pulse-glow" />
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <div className="mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card/50 border border-accent/20 backdrop-blur-sm mb-6 animate-fade-in-down">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-muted-foreground">
              AI-Powered Knowledge Assistant
            </span>
          </div>
          
          <h1 className="text-6xl lg:text-7xl font-bold mb-6 tracking-tight animate-fade-in-up">
            <span className="text-foreground">Query</span>
            <span className="text-primary glow-text">IQ</span>
          </h1>
          
          <p className="text-xl lg:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed animate-fade-in-delayed">
            Your team's tribal knowledge, instantly accessible. Connect to{" "}
            <span className="text-primary font-semibold">Notion</span>,{" "}
            <span className="text-primary font-semibold">Google Docs</span>, and{" "}
            <span className="text-primary font-semibold">Confluence</span>{" "}
            — ask anything, get smart answers.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12 animate-fade-in-delayed-2">
          <Button
            variant="hero"
            size="lg"
            className="min-w-48 hover:scale-105 transition-transform duration-200"
            onClick={() => navigate("/")}
          >
            Start Building Magic ✨
          </Button>
          <Button
            variant="ai"
            size="lg"
            className="min-w-48 hover:scale-105 transition-transform duration-200"
            onClick={() => navigate("/")}
          >
            See How It Works
          </Button>
        </div>

        <div className="text-sm text-muted-foreground animate-fade-in-delayed-3">
          <span className="opacity-70">Trusted by forward-thinking teams</span>
        </div>
      </div>
    </div>
  );
};