import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Sparkles, ArrowRight, Github, Mail } from "lucide-react";

export const CTA = () => {
  return (
    <div className="py-20 px-6">
      <div className="max-w-4xl mx-auto">
        <Card className="p-12 gradient-card border-accent/20 glow-card text-center relative overflow-hidden">
          {/* Background Effects */}
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
          <div className="absolute top-4 right-4 animate-float">
            <Sparkles className="w-6 h-6 text-primary animate-pulse-glow" />
          </div>
          <div className="absolute bottom-4 left-4 animate-float" style={{ animationDelay: '-3s' }}>
            <Sparkles className="w-4 h-4 text-accent animate-pulse-glow" />
          </div>
          
          <div className="relative z-10">
            <div className="mb-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 backdrop-blur-sm mb-6 animate-fade-in-down">
                <Sparkles className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-primary">
                  Ready to Build Magic?
                </span>
              </div>
              
              <h2 className="text-4xl lg:text-5xl font-bold mb-6 animate-fade-in-up">
                Let's Make Internal Knowledge Feel Like{" "}
                <span className="text-primary glow-text">Magic</span> ✨
              </h2>
              
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8 animate-fade-in-delayed">
                Join us in creating the future of team knowledge sharing. 
                Your expertise in beautiful frontend experiences could change how teams work forever.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8 animate-fade-in-delayed-2">
              <Button variant="hero" size="lg" className="min-w-48 hover:scale-105 transition-transform duration-200">
                <Github className="w-4 h-4" />
                View on GitHub
                <ArrowRight className="w-4 h-4" />
              </Button>
              <Button variant="ai" size="lg" className="min-w-48 hover:scale-105 transition-transform duration-200">
                <Mail className="w-4 h-4" />
                Let's Collaborate
              </Button>
            </div>

            <div className="text-sm text-muted-foreground">
              <p className="opacity-70">
                🔮 You'd be shaping how users feel when they trust AI to handle their team's tribal knowledge
              </p>
              <p className="opacity-70 mt-2">
                Think <span className="text-primary font-medium">Figma-clean</span> meets{" "}
                <span className="text-primary font-medium">Notion-sleek</span> — with a sprinkle of{" "}
                <span className="text-primary font-medium">glowing purple tech vibes</span>
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};