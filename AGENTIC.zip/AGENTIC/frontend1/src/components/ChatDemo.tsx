import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Bot, User, Send, Loader2 } from "lucide-react";

const demoMessages = [
  {
    id: 1,
    type: "user" as const,
    message: "What's our refund policy?",
    timestamp: "2:31 PM"
  },
  {
    id: 2,
    type: "bot" as const,
    message: "Based on your company policy in Notion, customers can request a full refund within 30 days of purchase. For digital products, refunds are processed within 3-5 business days. Would you like me to find the specific refund request form?",
    timestamp: "2:31 PM",
    sources: ["Company Policy - Notion", "Customer Support Guide"]
  },
  {
    id: 3,
    type: "user" as const,
    message: "How do I request design assets?",
    timestamp: "2:33 PM"
  },
  {
    id: 4,
    type: "bot" as const,
    message: "You can request design assets through our Design System in Figma or by submitting a request in #design-requests Slack channel. For brand assets, check the Brand Guidelines folder in Google Drive. Current turnaround time is 2-3 business days.",
    timestamp: "2:33 PM",
    sources: ["Design System - Figma", "Brand Guidelines - Google Drive"]
  }
];

export const ChatDemo = () => {
  const [visibleMessages, setVisibleMessages] = useState<typeof demoMessages>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (currentIndex < demoMessages.length) {
      const timer = setTimeout(() => {
        if (demoMessages[currentIndex].type === "bot") {
          setIsTyping(true);
          setTimeout(() => {
            setVisibleMessages(prev => [...prev, demoMessages[currentIndex]]);
            setIsTyping(false);
            setCurrentIndex(prev => prev + 1);
          }, 1500);
        } else {
          setVisibleMessages(prev => [...prev, demoMessages[currentIndex]]);
          setCurrentIndex(prev => prev + 1);
        }
      }, currentIndex === 0 ? 500 : 2000);

      return () => clearTimeout(timer);
    }
  }, [currentIndex]);

  const resetDemo = () => {
    setVisibleMessages([]);
    setCurrentIndex(0);
    setIsTyping(false);
  };

  return (
    <div className="py-20 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 animate-fade-in-up">
            See <span className="text-primary">QueryIQ</span> in Action
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-in-delayed">
            Watch how your team's questions get instant, accurate answers from your knowledge base
          </p>
        </div>

        <Card className="max-w-2xl mx-auto gradient-card border-accent/20 glow-card animate-scale-in" style={{ animationDelay: '0.3s' }}>
          <div className="p-6">
            {/* Chat Header */}
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-accent/20">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full gradient-primary flex items-center justify-center">
                  <Bot className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold">QueryIQ Assistant</h3>
                  <p className="text-sm text-muted-foreground">Online • Ready to help</p>
                </div>
              </div>
              <Button variant="ai" size="sm" onClick={resetDemo}>
                Replay Demo
              </Button>
            </div>

            {/* Chat Messages */}
            <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
              {visibleMessages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.type === "user" ? "justify-end" : "justify-start"} animate-slide-in-left`}>
                  <div className={`max-w-[80%] ${msg.type === "user" ? "order-2" : "order-1"}`}>
                    <div className={`flex items-start gap-3 ${msg.type === "user" ? "flex-row-reverse" : "flex-row"}`}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                        msg.type === "user" 
                          ? "bg-secondary" 
                          : "gradient-primary"
                      }`}>
                        {msg.type === "user" ? (
                          <User className="w-4 h-4" />
                        ) : (
                          <Bot className="w-4 h-4 text-white" />
                        )}
                      </div>
                      <div className={`${msg.type === "user" ? "text-right" : "text-left"}`}>
                        <div className={`inline-block p-3 rounded-lg ${
                          msg.type === "user" 
                            ? "bg-primary text-white" 
                            : "bg-muted border border-accent/20"
                        }`}>
                          <p className="text-sm">{msg.message}</p>
                        </div>
                        {msg.sources && (
                          <div className="mt-2 space-y-1">
                            <p className="text-xs text-muted-foreground">Sources:</p>
                            {msg.sources.map((source, idx) => (
                              <div key={idx} className="text-xs bg-accent/10 border border-accent/20 rounded px-2 py-1 inline-block mr-1">
                                {source}
                              </div>
                            ))}
                          </div>
                        )}
                        <p className="text-xs text-muted-foreground mt-1">{msg.timestamp}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {/* Typing Indicator */}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full gradient-primary flex items-center justify-center">
                      <Bot className="w-4 h-4 text-white" />
                    </div>
                    <div className="bg-muted border border-accent/20 rounded-lg p-3">
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin text-primary" />
                        <span className="text-sm text-muted-foreground">QueryIQ is thinking...</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Chat Input */}
            <div className="flex gap-2">
              <div className="flex-1 bg-muted border border-accent/20 rounded-lg px-4 py-3">
                <p className="text-sm text-muted-foreground">Ask anything about your team's knowledge...</p>
              </div>
              <Button variant="ai" size="icon">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};