import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import {
  SignedIn,
  SignedOut,
  SignInButton,
  SignUpButton,
  UserButton,
} from "@clerk/clerk-react";
import React from "react";

const queryClient = new QueryClient();

const AuthCard = () => (
  <div className="flex flex-col items-center justify-center bg-white rounded-2xl shadow-2xl p-10 gap-6 border border-purple-200 w-[370px] min-h-[420px] animate-fadeInUp">
    <div className="flex items-center justify-center w-20 h-20 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full shadow-lg mb-2 animate-bounce">
      <span className="text-4xl text-white">💬</span>
    </div>
    <h1 className="text-3xl font-extrabold text-purple-700 mb-2">Welcome to ChatVerse</h1>
    <p className="text-md text-gray-600 mb-4">Sign in or create an account to use the chatbot</p>
    <div className="flex flex-col gap-4 w-full">
      <SignInButton>
        <button className="w-full px-6 py-2 rounded-lg bg-gradient-to-r from-purple-500 to-purple-700 text-white font-bold shadow-lg hover:scale-105 transition-all duration-300 animate-fadeInUp">
          Sign In
        </button>
      </SignInButton>
      <SignUpButton>
        <button className="w-full px-6 py-2 rounded-lg bg-gradient-to-r from-purple-400 to-purple-600 text-white font-bold shadow-lg hover:scale-105 transition-all duration-300 animate-fadeInUp">
          Sign Up
        </button>
      </SignUpButton>
    </div>
    <div className="mt-4 text-center text-sm text-purple-600 animate-fadeIn">
      Not a member?{' '}
      <span className="underline cursor-pointer text-purple-700 font-semibold" onClick={() => (document.querySelector('button[aria-label="Sign up"]') as HTMLElement)?.click()}>
        Signup now
      </span>
    </div>
    <div className="mt-2 text-xs text-gray-400 animate-fadeIn">✨ Secure, fast, and always available ✨</div>
  </div>
);

const App = () => (
  <header>
    <SignedOut>
      <div className="min-h-screen flex flex-col items-center justify-center">
        <AuthCard />
      </div>
    </SignedOut>
    <SignedIn>
      <UserButton />
      {/* Place your chatbot and main app here */}
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </QueryClientProvider>
    </SignedIn>
  </header>
);

export default App;
